## R-1: Coordinate Frames & Transform Error Propagation in LiDAR

### 1. Why Small Rotation Errors Become Large Spatial Errors

LiDAR measures points in its **sensor coordinate frame**, which must be transformed into the vehicle or world frame using an extrinsic calibration (rotation + translation).
If the rotation is slightly wrong (e.g., a small pitch, roll, or yaw bias), the error is **angular**, not linear. When this angular error is applied to points farther from the sensor, it produces a displacement that **grows linearly with range**:

$$
\Delta \approx r \cdot \theta
$$

Where:

- ( $$r$$ ) = distance from sensor
- ( $$\theta$$ ) = small rotation error (radians)

This means:

- Nearby geometry looks correct.
- Far geometry is increasingly misaligned.
- The issue can remain hidden during quick visual inspection but becomes severe for mapping, tracking, and fusion.

**Example:** A $$0.1°$$ yaw error ($$~0.0017 rad$$)

- At $$10 m$$ → $$~1.7 cm$$ shift
- At $$50 m$$ → $$~8.5 cm$$ shift
- At $$100 m$$ → $$~17 cm$$ shift

Thus, rotational calibration errors manifest as **range-dependent distortion**, not uniform noise.

---

### 2. Observable Symptoms Without Ground Truth

Even without labeled data or reference maps, this error produces identifiable geometric artifacts in raw point clouds:

- **Planar surfaces appear “thick”** (walls look doubled or smeared).
- **Vertical structures tilt with distance** (light poles lean or split).
- **Ground plane curvature** appears when pitch/roll are biased.
- **Multi-frame accumulation shows ghosting**—static objects appear replicated.
- Registration residuals increase with distance from the sensor.

These symptoms are diagnostic because true LiDAR noise is roughly range-independent in angle space, while calibration error grows with range.

---

### 3. Diagnosing the Problem Using Only Geometry

We can detect transform error by checking **self-consistency constraints** in the environment:

#### a. Plane Stability vs. Distance

Fit planes to large structures (road, building façades) and evaluate point-to-plane residuals as a function of range.

$$
\text{Residual}(r) \propto r \Rightarrow \text{rotational miscalibration}
$$

If the calibration were correct, residual variance would remain approximately constant.

#### b. Overlap Consistency Between Consecutive Scans

Register sequential scans (e.g., ICP) and analyze residual vectors:

- A systematic directional drift indicates a biased rotation.
- Increasing correction magnitude with range is a key signal.

#### c. Symmetry Checks in Static Scenes

Urban scenes contain many orthogonal structures.
Deviation from expected orthogonality (e.g., walls not perpendicular to ground) reveals small angular misalignments.

These methods require **no ground truth**, only the assumption that the world is locally rigid and structured.

---

### 4. Practical Mitigation Strategies

Rather than performing expensive global recalibration, systems can apply **online mitigation**:

#### a. Ground-Plane Anchoring (Pitch/Roll Stabilization)

Continuously estimate the ground plane and enforce its normal to align with gravity (from IMU or assumed vertical).
This corrects slow drift in $$pitch/roll$$.

#### b. Range-Weighted Registration

During scan matching, weight correspondences by inverse distance:

$$
w = \frac{1}{r}
$$

This prevents far points (which amplify angular error) from dominating optimization.

#### c. Structural Self-Calibration

Use stable planar or vertical features detected during operation to solve for a small corrective rotation that minimizes range-dependent residual growth.

#### d. Health Monitoring Metric

Track:

$$
\frac{d}{dr}\text{Residual}(r)
$$

A rising slope is an indicator of calibration degradation and can trigger re-calibration or confidence reduction in downstream perception.

---

### 5. Key Insight

Rotational extrinsic errors are dangerous because they are **not additive noise** - they are **multiplicative geometric distortions** that scale with distance.
By exploiting environmental structure and analyzing residuals as a function of range, we can both diagnose and mitigate these errors without requiring labeled datasets or external references.

---

### Conclusion

Understanding how small angular uncertainties propagate through coordinate transforms is essential for reliable **LiDAR** perception. A combination of geometric diagnostics and lightweight online correction allows systems to maintain spatial accuracy even when perfect calibration is not available.
