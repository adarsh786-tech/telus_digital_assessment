import unittest
from guardrail_parser import (
    LLMStructuredOutputParser,
    ExtractionError,
    SchemaValidationError,
    ContextValidationError,
)

ALLOWED_IDS = ["BOX_1", "BOX_2", "BOX_3"]


class TestLLMStructuredOutputParser(unittest.TestCase):

    def setUp(self):
        self.parser = LLMStructuredOutputParser(ALLOWED_IDS)

    # --------------------------------------------------
    # VALID CASES
    # --------------------------------------------------

    def test_valid_clean_json(self):
        raw = '{"id": "BOX_1", "score": 0.85}'
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_1")
        self.assertAlmostEqual(result["score"], 0.85)

    def test_trailing_text(self):
        raw = """
        Here is the result:
        {"id": "BOX_2", "score": 0.72}
        Hope this helps!
        """
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_2")

    def test_single_quotes_and_trailing_comma(self):
        raw = "{'id': 'BOX_3', 'score': 0.9,}"
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_3")

    def test_score_clamping(self):
        raw = '{"id": "BOX_1", "score": 5.7}'
        result = self.parser.parse(raw)
        self.assertEqual(result["score"], 1.0)

    def test_optional_reason_field(self):
        raw = '{"id": "BOX_2", "score": 0.6, "reason": "Good alignment"}'
        result = self.parser.parse(raw)
        self.assertIn("reason", result)

    # --------------------------------------------------
    # FAILURE CASES
    # --------------------------------------------------

    def test_missing_required_field(self):
        raw = '{"id": "BOX_1"}'
        with self.assertRaises(SchemaValidationError):
            self.parser.parse(raw)

    def test_extra_hallucinated_field(self):
        raw = '{"id": "BOX_1", "score": 0.5, "confidence": "high"}'
        with self.assertRaises(SchemaValidationError):
            self.parser.parse(raw)

    def test_invalid_id_not_in_context(self):
        raw = '{"id": "FAKE_BOX", "score": 0.8}'
        with self.assertRaises(ContextValidationError):
            self.parser.parse(raw)

    def test_no_json_present(self):
        raw = "The model refuses to answer."
        with self.assertRaises(ExtractionError):
            self.parser.parse(raw)

    def test_malformed_json_unrecoverable(self):
        raw = '{"id": "BOX_1", "score": }'
        with self.assertRaises(Exception):
            self.parser.parse(raw)

    def test_wrong_type_score(self):
        raw = '{"id": "BOX_1", "score": "high"}'
        with self.assertRaises(SchemaValidationError):
            self.parser.parse(raw)

    # --------------------------------------------------
    # REALISTIC LLM FAILURE MODES
    # --------------------------------------------------

    def test_markdown_wrapped_json(self):
        raw = """
        ```json
        {
            "id": "BOX_2",
            "score": 0.77
        }
        ```
        """
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_2")

    def test_comment_inside_json(self):
        raw = """
        {
            "id": "BOX_3", // detected object
            "score": 0.88
        }
        """
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_3")

    def test_multiple_json_blocks_uses_first(self):
        raw = """
        {"id": "BOX_1", "score": 0.5}
        {"id": "BOX_2", "score": 0.9}
        """
        result = self.parser.parse(raw)
        self.assertEqual(result["id"], "BOX_1")


if __name__ == "__main__":
    unittest.main()
