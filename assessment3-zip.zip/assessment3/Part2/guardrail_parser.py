import json
import re
from dataclasses import dataclass, field
from typing import List, Dict, Any, Set


# ------------------------------------------------------------
# CONFIGURATION OBJECT (Production-style dependency injection)
# ------------------------------------------------------------
@dataclass
class ParserConfig:
    required_keys: Set[str] = field(default_factory=lambda: {"id", "score"})
    optional_keys: Set[str] = field(default_factory=lambda: {"reason"})
    clamp_score: bool = True
    score_range: tuple = (0.0, 1.0)

    @property
    def allowed_keys(self) -> Set[str]:
        return self.required_keys | self.optional_keys


# ------------------------------------------------------------
# CUSTOM EXCEPTIONS (important in real systems)
# ------------------------------------------------------------
class ExtractionError(Exception):
    pass


class NormalizationError(Exception):
    pass


class SchemaValidationError(Exception):
    pass


class ContextValidationError(Exception):
    pass


# ------------------------------------------------------------
# CORE PARSER CLASS
# ------------------------------------------------------------
class LLMStructuredOutputParser:
    """
    Production-grade guardrail for parsing unreliable LLM outputs.
    """

    def __init__(self, allowed_ids: List[str], config: ParserConfig = ParserConfig()):
        self.allowed_ids = set(allowed_ids)
        self.config = config

    # ---------------------------
    # PUBLIC API
    # ---------------------------
    def parse(self, raw_text: str) -> Dict[str, Any]:
        """
        Full pipeline:
        extract → normalize → parse → validate → context-check
        """
        json_block = self._extract_json_block(raw_text)
        normalized = self._normalize(json_block)
        data = self._safe_load_json(normalized)
        validated = self._validate_schema(data)
        self._validate_context(validated)
        return validated

    # ---------------------------
    # STEP 1 — Extraction
    # ---------------------------
    def _extract_json_block(self, text: str) -> str:
        start = text.find("{")
        if start == -1:
            raise ExtractionError("No JSON object detected in LLM output.")

        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]

        raise ExtractionError("Unbalanced braces in LLM output.")

    # ---------------------------
    # STEP 2 — Normalization
    # ---------------------------
    def _normalize(self, text: str) -> str:
        try:
            text = re.sub(r"'", '"', text)
            text = re.sub(r",\s*}", "}", text)
            text = re.sub(r",\s*]", "]", text)
            text = re.sub(r'"\s+"', '", "', text)
            text = re.sub(r"//.*", "", text)
            return text
        except Exception as e:
            raise NormalizationError(f"Normalization failed: {e}")

    # ---------------------------
    # STEP 3 — JSON Loading
    # ---------------------------
    def _safe_load_json(self, text: str) -> Dict[str, Any]:
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise NormalizationError(f"JSON parsing failed after repair: {e}")

    # ---------------------------
    # STEP 4 — Schema Validation
    # ---------------------------
    def _validate_schema(self, obj: Dict[str, Any]) -> Dict[str, Any]:
        keys = set(obj.keys())

        missing = self.config.required_keys - keys
        if missing:
            raise SchemaValidationError(f"Missing required keys: {missing}")

        extra = keys - self.config.allowed_keys
        if extra:
            raise SchemaValidationError(f"Unexpected keys from LLM: {extra}")

        if not isinstance(obj["id"], str):
            raise SchemaValidationError("Field 'id' must be string.")

        if not isinstance(obj["score"], (int, float)):
            raise SchemaValidationError("Field 'score' must be numeric.")

        if self.config.clamp_score:
            lo, hi = self.config.score_range
            obj["score"] = float(max(lo, min(hi, obj["score"])))

        return obj

    # ---------------------------
    # STEP 5 — Context Validation
    # ---------------------------
    def _validate_context(self, obj: Dict[str, Any]) -> None:
        if obj["id"] not in self.allowed_ids:
            raise ContextValidationError(
                f"ID '{obj['id']}' not present in trusted context."
            )
