from guardrail_parser import LLMStructuredOutputParser

allowed_ids = ["BOX_1", "BOX_2", "BOX_3"]

parser = LLMStructuredOutputParser(allowed_ids)

raw_llm_output = """
Sure! Here's the answer:

{
    'id': 'BOX_1',
    'score': 1.3,
    'reason': 'Strong geometry match',
}

Let me know if you need more help!
"""

try:
    result = parser.parse(raw_llm_output)
    print("Validated Output:", result)
except Exception as e:
    print("Rejected:", e)
