# Geometry-Only Cuboid Pre-label Validation (CV-2)

## Overview

This project implements a **geometry-only validator** that scores 3D cuboid pre-labels using point cloud data — **without any ML models**.
Given a point cloud and candidate cuboids, the system outputs:

```json
{ "score": [0, 1], "reason": "<diagnostic message>" }
```

It detects common annotation failures such as:

- Empty / phantom boxes
- Misaligned (drifted) labels
- Planar artifacts (points only on one face)
- Sparse / non-volumetric regions

---

## Architecture Decisions

The code is structured to mirror a **production perception QA module**, separating geometry, signal extraction, and decision logic.

```
geometry/        → Primitive spatial objects (Cuboid)
metrics/         → Pure geometric measurements (no policy)
core/            → Validation engine + scoring logic
data/            → Synthetic test scene generation
tests/           → Unit + behavioral tests
```

### Why This Structure?

| Layer          | Responsibility        | Reason                        |
| -------------- | --------------------- | ----------------------------- |
| Geometry       | Spatial math only     | Reusable across pipelines     |
| Metrics        | Measurable signals    | Keeps validation explainable  |
| Validator      | Policy + scoring      | Allows threshold tuning       |
| Synthetic Data | Controlled failures   | Enables deterministic testing |
| Tests          | Contract verification | Ensures reliability           |

This separation avoids mixing **math**, **heuristics**, and **evaluation policy**, making the system extensible to real datasets.

---

## Validation Signals (No Machine Learning)

Each cuboid is evaluated using deterministic geometry:

1. **Point Density**
   Detects empty or weakly supported boxes.

   $$
   density = \frac{\text{points inside}}{\text{cuboid volume}}
   $$

2. **Volumetric Fill Ratio**
   Uses voxel occupancy to ensure the object fills space rather than lying on a surface.

3. **Centroid Offset**
   Measures annotation drift between box center and observed points.

4. **PCA Shape Analysis**
   Eigenvalue ratios detect planar / linear structures:
   - Planar → “points only on one face”
   - Linear → edge artifact

These signals are fused into a bounded confidence score.

---

## Data Strategy

### Why Synthetic Data?

The assignment allows synthetic scenes. We intentionally generate controlled cases:

| Scene          | Purpose                |
| -------------- | ---------------------- |
| Valid object   | Expected correct label |
| Empty scene    | Phantom annotation     |
| Planar failure | Box over ground/wall   |
| Drifted object | Misaligned annotation  |

Synthetic data is sufficient because:

- We are validating **geometry behavior**, not training a model.
- Ground truth is analytically known.
- Deterministic failures are easier to verify than real-world noise.
- This mirrors how perception teams unit-test label validators before deployment.

---

## How to Run

### 1️⃣ Install Dependencies

```
pip install numpy pytest
```

---

### 2️⃣ Run Test Suite

```
pytest -v
```

Tests cover:

- Geometry correctness
- Failure detection behavior
- Score stability
- Edge cases (empty input, small samples)

---

## How You Can Trust the Solution Works

✔ Deterministic metrics — no stochastic ML behavior
✔ Unit tests validate each failure mode independently
✔ Synthetic scenes provide known expected outcomes
✔ Scoring bounded and explainable (no black-box logic)
✔ Modular design allows inspection of intermediate signals

This mirrors **dataset QA pipelines used in autonomy stacks**, where labels are filtered before training.

---

## Assumptions

- Cuboids are **axis-aligned** (simplifies reasoning without losing validation power).
- Input point cloud is already in a consistent coordinate frame.
- We validate **label plausibility**, not object classification.
- Noise levels are moderate (extreme LiDAR sparsity would require adaptive thresholds).

---

## Trade-offs

| Decision             | Benefit                     | Trade-off                            |
| -------------------- | --------------------------- | ------------------------------------ |
| Axis-aligned boxes   | Simpler, deterministic math | No rotated-box handling              |
| Heuristic scoring    | Fully explainable           | Not statistically learned            |
| Synthetic evaluation | Controlled validation       | Not benchmarking real datasets       |
| Voxel fill metric    | Captures volumetric support | Resolution-sensitive                 |
| No ML allowed        | Meets assignment goal       | Cannot learn dataset-specific priors |

---

## Possible Extensions (Future Modifications)

- Support oriented bounding boxes (OBB)
- Dataset calibration using KITTI / nuScenes
- Visualization via Open3D
- Batch validation pipeline for large datasets

---

## Deliverable Contents

```
geometry/      Cuboid primitive
metrics/       Geometry measurements
core/          Validator engine
data/          Synthetic scene generator
tests/         Pytest suite
README.md      (this file)
```

---

**This implementation satisfies the requirement to identify bad 3D labels using geometry alone, without any trained models.**
