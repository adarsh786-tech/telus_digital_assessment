import numpy as np
from ..geometry.cuboid import Cuboid


def test_points_inside():
    cuboid = Cuboid(center=(0,0,0), size=(2,2,2))
    pts = np.array([[0,0,0], [0.5,0,0]])

    inside = cuboid.crop(pts)
    assert len(inside) == 2


def test_points_outside():
    cuboid = Cuboid(center=(0,0,0), size=(2,2,2))
    pts = np.array([[5,5,5]])

    inside = cuboid.crop(pts)
    assert len(inside) == 0


def test_volume():
    cuboid = Cuboid(center=(0,0,0), size=(2,3,4))
    assert cuboid.volume == 24
