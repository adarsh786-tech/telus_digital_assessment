from ..geometry.cuboid import Cuboid
from ..core.validator import CuboidValidator
from ..data.synthetic_scene import valid_object, planar_failure, drifted_object, empty


validator = CuboidValidator()
cuboid = Cuboid(center=(0,0,0), size=(4,2,1.5))


def test_valid_object():
    pts = valid_object()
    result = validator.validate(pts, cuboid)
    assert result["reason"] == "valid"
    assert result["score"] > 0.6


def test_empty_box():
    pts = empty()
    result = validator.validate(pts, cuboid)
    assert result["reason"] == "empty box"
    assert result["score"] == 0.0


def test_planar_failure():
    pts = planar_failure()
    result = validator.validate(pts, cuboid)
    assert "face" in result["reason"]


def test_drift_failure():
    pts = drifted_object()
    result = validator.validate(pts, cuboid)
    assert result["reason"] == "center drift"
