import numpy as np


class Cuboid:
    """
    Axis-aligned 3D cuboid.
    Used as a geometric primitive for validation.
    """

    def __init__(self, center, size):
        self.center = np.asarray(center, dtype=float)
        self.size = np.asarray(size, dtype=float)

        if np.any(self.size <= 0):
            raise ValueError("Cuboid size must be positive.")

        self.min_corner = self.center - self.size / 2
        self.max_corner = self.center + self.size / 2

    def contains(self, points: np.ndarray) -> np.ndarray:
        """Boolean mask of points inside cuboid."""
        return np.all(
            (points >= self.min_corner) & (points <= self.max_corner),
            axis=1
        )

    def crop(self, points: np.ndarray) -> np.ndarray:
        """Return only points inside cuboid."""
        return points[self.contains(points)]

    @property
    def volume(self) -> float:
        return float(np.prod(self.size))

    def __repr__(self):
        return f"Cuboid(center={self.center.tolist()}, size={self.size.tolist()})"
