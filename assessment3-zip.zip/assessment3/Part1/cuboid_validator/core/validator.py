from ..metrics.geometry_metrics import GeometryMetrics


class CuboidValidator:
    """
    Geometry-only cuboid validation engine.
    """

    def __init__(
        self,
        min_points=30,
        min_density=4.0,
        min_fill=0.02,
        max_offset=1.0,
    ):
        self.min_points = min_points
        self.min_density = min_density
        self.min_fill = min_fill
        self.max_offset = max_offset

    def validate(self, points, cuboid):
        inside = cuboid.crop(points)

        if len(inside) < self.min_points:
            return self._result(0.0, "empty box")

        density = GeometryMetrics.density(inside, cuboid.volume)
        fill = GeometryMetrics.fill_ratio(inside, cuboid)
        offset = GeometryMetrics.center_offset(inside, cuboid.center)
        shape_score, shape_reason = GeometryMetrics.pca_shape(inside)

        score = self._score(density, fill, offset, shape_score)

        if density < self.min_density:
            return self._result(score, "low density")

        if fill < self.min_fill:
            return self._result(score, "not volumetric")

        if offset > self.max_offset:
            return self._result(score, "center drift")

        if shape_reason:
            return self._result(score, shape_reason)

        return self._result(score, "valid")

    def _score(self, density, fill, offset, shape):
        density_term = min(1.0, density / (self.min_density * 2))
        offset_term = max(0.0, 1 - offset / (self.max_offset * 2))

        return float(0.4 * density_term + 0.3 * fill + 0.2 * offset_term + 0.1 * shape)

    @staticmethod
    def _result(score, reason):
        return {"score": round(score, 3), "reason": reason}
