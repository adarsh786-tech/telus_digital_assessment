import numpy as np


def valid_object(center=(0, 0, 0), size=(4, 2, 1.5), n=400):
    pts = np.random.uniform(-0.5, 0.5, (n, 3)) * size
    return pts + center


def planar_failure(center=(0, 0, 0), size=(4, 2, 1.5), n=300):
    x = np.random.uniform(-size[0]/2, size[0]/2, n)
    y = np.random.uniform(-size[1]/2, size[1]/2, n)
    z = np.zeros(n)
    return np.vstack([x, y, z]).T + center


def drifted_object():
    return valid_object() + np.array([3, 0, 0])


def empty():
    return np.empty((0, 3))
