import numpy as np


class GeometryMetrics:

    @staticmethod
    def density(points, volume):
        if len(points) == 0:
            return 0.0
        return len(points) / volume

    @staticmethod
    def center_offset(points, cuboid_center):
        if len(points) == 0:
            return float("inf")
        centroid = points.mean(axis=0)
        return float(np.linalg.norm(centroid - cuboid_center))

    @staticmethod
    def pca_shape(points):
        """
        Detect planar / linear structures using eigenvalues.
        """
        if len(points) < 5:
            return 0.0, "insufficient points"

        centered = points - points.mean(axis=0)
        cov = centered.T @ centered / len(points)

        eigvals = np.sort(np.linalg.eigvalsh(cov))[::-1]
        l1, l2, l3 = eigvals + 1e-6

        planarity = (l2 - l3) / l1
        linearity = (l1 - l2) / l1

        if planarity > 0.75:
            return 0.2, "points only on one face"

        if linearity > 0.8:
            return 0.3, "edge-like structure"

        return 1.0, None

    @staticmethod
    def fill_ratio(points, cuboid, resolution=6):
        if len(points) == 0:
            return 0.0

        normalized = (points - cuboid.min_corner) / cuboid.size
        idx = np.clip((normalized * resolution).astype(int), 0, resolution - 1)

        occupied = set(tuple(i) for i in idx)
        return len(occupied) / (resolution ** 3)
